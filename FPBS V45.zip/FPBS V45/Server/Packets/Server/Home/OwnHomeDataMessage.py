import time
import random

from Server.ByteStreamHelper import ByteStreamHelper
from Server.Packets.PiranhaMessage import PiranhaMessage


class OwnHomeDataMessage(PiranhaMessage):
    def __init__(self, messageData):
        super().__init__(messageData)
        self.messageVersion = 0

    def encode(self, fields, player):
    	
        self.writeVInt(-1433793731) # Timestamp
        self.writeVInt(2023064) # Timestamp
        self.writeVInt(-1433793731) # Timestamp
        self.writeVInt(2023064) # Timestamp        
        
        self.writeVInt(0) # Trophies
        self.writeVInt(50000) # Highest Trophies
        self.writeVInt(0)
        self.writeVInt(333) # Trophy Road Tier
        self.writeVInt(999999) # Experience
        self.writeDataReference(28, 129) # Profile Icon
        self.writeDataReference(43, 10) # Name Color

        self.writeVInt(26) # Played Game Mode
        for i in range(26):
            self.writeVInt(i)
        
        self.writeVInt(1) # Selected Skin
        self.writeDataReference(29, 558)

        self.writeVInt(0) # Randomizer Skin Selected

        self.writeVInt(0) # Current Random Skin

        self.writeVInt(583) # Unlocked Skins 
        for i in range(583): 
            self.writeDataReference(29, i)

        self.writeVInt(0) # Unlocked Skin Purchase Option

        self.writeVInt(0) # New Item State


        self.writeVInt(0)
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeVInt(1)
        self.writeBoolean(True)
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeVInt(0)

        self.writeVInt(999)
        self.writeVInt(999)

        self.writeVInt(5)

        self.writeVInt(999)
        self.writeVInt(999)
        self.writeVInt(999)
        self.writeVInt(999)
        self.writeVInt(999)

        self.writeBoolean(False) # Offer 1
        self.writeBoolean(False) # Offer 2
        self.writeBoolean(True) # Token Doubler Enabled
        
        self.writeVInt(2) 
        self.writeVInt(2) 
        self.writeVInt(2)
        
        self.writeVInt(0) # Name Change Cost
        self.writeVInt(0) # Name Change Timer

        self.writeVInt(0) # Offers Count                                                                                              
        self.writeVInt(200) # Tokens
        self.writeVInt(-1)

        self.writeVInt(0)

        self.writeVInt(0)
        self.writeVInt(0)

        self.writeVInt(1) # Selected Skin
        self.writeDataReference(16, 11) # Selected Brawler

        self.writeString("UA") # Location
        self.writeString("F1ize") # Content Creator

        self.writeVInt(1)
        self.writeInt(18)
        self.writeInt(1)
			
        self.writeVInt(0)

        self.writeVInt(2)  # Brawl Pass
        for i in [12, 13]:
            self.writeVInt(i)
            self.writeVInt(34500)
            self.writeBoolean(True)
            self.writeVInt(0)

            self.writeByte(2)
            self.writeInt(0)
            self.writeInt(0)
            self.writeInt(0)
            self.writeInt(0)

            self.writeByte(1)
            self.writeInt(0)
            self.writeInt(0)
            self.writeInt(0)
            self.writeInt(0)

        self.writeVInt(0)

        self.writeBoolean(True) # Quests
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeVInt(0) 
          
        self.writeBoolean(True)
        self.writeVInt(853 + 107 + 82)  # Vanity Count
        for i in range(853):
            self.writeDataReference(52, i)
            self.writeVInt(1)
            for i in range(1):
                self.writeVInt(1)
                self.writeVInt(1)
                
        for i in range(107):
            self.writeDataReference(28, i)
            self.writeVInt(1)
            for i in range(1):
                self.writeVInt(1)
                self.writeVInt(1)         
                
        for i in range(82):
            self.writeDataReference(68, i)
            self.writeVInt(1)
            for i in range(1):
                self.writeVInt(1)
                self.writeVInt(1)

        self.writeBoolean(True) # Power League Array
        # Power League Data Array Start #
        self.writeVInt(9) # Season
        self.writeVInt(19) # Rank Solo League
        self.writeVInt(9) # Season
        self.writeVInt(19) # Rank Team League
        self.writeVInt(0) # Unk
        self.writeVInt(19) # High Rank Solo League
        self.writeVInt(0) # Unk
        self.writeVInt(19) # High Rank Team League
        self.writeVInt(0) # Unk
        self.writeBoolean(True) # Eligibility for an award
        self.writeVInt(0) # Unk
        self.writeVInt(0) # Array
        # Power League Data Array End #

        self.writeInt(0)

        self.writeVInt(0)

        self.writeVInt(26) # Count

        # Event Slots IDs Array Start #
        self.writeVInt(1) # Gem Grab
        self.writeVInt(2) # Showdown
        self.writeVInt(3) # Daily Events
        self.writeVInt(4) # Team Events
        self.writeVInt(5) # Duo Showndown
        self.writeVInt(6) # Team Events 2
        self.writeVInt(7) # Special Events(Big Game and other…)
        self.writeVInt(8) # Solo Events (As well as Seasonal Events)
        self.writeVInt(9) # Power Play (Not working)
        self.writeVInt(10) # Seasonal Events
        self.writeVInt(11) # Seasonal Events 2
        self.writeVInt(12) # Candidates of The Day
        self.writeVInt(13) # Winner of The Day
        self.writeVInt(14) # Solo Mode Power League
        self.writeVInt(15) # Team Mode Power League
        self.writeVInt(16) # Club League(Default Map)
        self.writeVInt(17) # Club League(Power Match)
        self.writeVInt(18) # Mystery Mode
        self.writeVInt(20) # Championship Challenge (Stage 1)
        self.writeVInt(21) # Championship Challenge (Stage 2)
        self.writeVInt(22) # Championship Challenge (Stage 3)
        self.writeVInt(23) # Championship Challenge (Stage 4)
        self.writeVInt(24) # Championship Challenge (Stage 5)
        self.writeVInt(30) # Team Events 3?
        self.writeVInt(31) # Team Events 4?
        self.writeVInt(32) # Team Events 5?
        # Event Slots IDs Array End #
        
        maps = [552, 16, 534, 266, 37, 429, 324, 543, 0, 479, 46, 174, 557]
        self.writeVInt(len(maps) + 3) # Events
        eventIndex = 1
        for i in maps:
            self.writeVInt(-1)
            self.writeVInt(eventIndex)  # EventType
            self.writeVInt(0)  # EventsBeginCountdown
            self.writeVInt(0) # Timer
            self.writeVInt(0) # Tokens
            self.writeDataReference(15, i)  # MapID
            self.writeVInt(-1)  # GameModeVariation
            self.writeVInt(2)  # State
            self.writeString()
            self.writeVInt(0)
            self.writeVInt(0)
            self.writeVInt(0)
            self.writeVInt(0)  # Modifiers
            self.writeVInt(0)
            self.writeVInt(0)
            self.writeBoolean(False)  # Map Maker Map Structure Array
            self.writeVInt(0)
            self.writeBoolean(False)  # Power League Data Array
            self.writeVInt(0)
            self.writeVInt(0)
            self.writeBoolean(False)  # ChronosTextEntry
            self.writeBoolean(False)
            self.writeBoolean(False)
            self.writeVInt(-1)
            self.writeBoolean(False)
            self.writeBoolean(False)
            self.writeVInt(-1)
            eventIndex += 1            
        # Default Slots End Array #
          
        # Mystery Slot Start Array #        
        self.writeVInt(0)
        self.writeVInt(18)  # EventType
        self.writeVInt(0)  # EventsBeginCountdown
        self.writeVInt(0)  # Timer
        self.writeVInt(0)  # tokens reward for new event
        self.writeDataReference(15, random.randint(561,566))  # MapID
        self.writeVInt(-1)  # GameModeVariation
        self.writeVInt(2)  # State
        self.writeString()
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeVInt(0)  # Modifiers
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeBoolean(False)  # Map Maker Map Structure Array
        self.writeVInt(0)
        self.writeBoolean(False)  # Power League Data Array
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeBoolean(False)  # ChronosTextEntry
        self.writeBoolean(False)
        self.writeBoolean(False)
        self.writeVInt(-1)
        self.writeBoolean(False)
        self.writeBoolean(False)
        self.writeVInt(-1)
       # Mystery Slots End Array #             
                                                                     
       # Power League Solo Mode #
        self.writeVInt(0)
        self.writeVInt(14)  # EventType
        self.writeVInt(0)  # EventsBeginCountdown
        self.writeVInt(5184000)  # Timer
        self.writeVInt(0)  # Tokens
        self.writeDataReference(0, 2)  # MapID
        self.writeVInt(-64)  # GameModeVariation
        self.writeVInt(2)  # State
        self.writeString()
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeVInt(60)
        self.writeVInt(0)
        self.writeBoolean(False)  # Map Maker Map Structure Array
        self.writeVInt(0)
        self.writeBoolean(True)  # Power League Data Array
        # Power League Data Array Start #
        self.writeVInt(9) # Season
        self.writeString("TID_BRAWL_PASS_SEASON_13") # Name Season
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeVInt(3) # Quests Count
        
        self.writeByte(3) # LogicRewardConfig
        self.writeByte(4) # Quest Type
        self.writeVInt(30) # Rank
        self.writeVInt(1) # Item Array
        self.writeVInt(25) # ItemType
        self.writeVInt(1) 
        self.writeVInt(0)
        self.writeVInt(127) # Thumbnail ID
        
        self.writeByte(3) # LogicRewardConfig
        self.writeByte(2) # Quest Type
        self.writeVInt(7) # Rank
        self.writeVInt(1) # Item Array
        self.writeVInt(25) # ItemType
        self.writeVInt(1) 
        self.writeVInt(0)
        self.writeVInt(128) # Thumbnail ID
        
        self.writeByte(3) # LogicRewardConfig
        self.writeByte(4) # Quest Type
        self.writeVInt(60) # Wins need
        self.writeVInt(1) # Item Array
        self.writeVInt(26) # ItemType
        self.writeVInt(1) 
        self.writeVInt(0)
        self.writeVInt(568) # SkinID
        
        self.writeVInt(19) # Road Count
        
        self.writeVInt(1) # Rank
        self.writeVInt(500) # Starpoints
        self.writeVInt(2) # Rank
        self.writeVInt(1000) # Starpoints
        self.writeVInt(3)  # Rank
        self.writeVInt(2000) # Starpoints
        self.writeVInt(4)  # Rank
        self.writeVInt(2500) # Starpoints
        self.writeVInt(5)  # Rank
        self.writeVInt(3000) # Starpoints
        self.writeVInt(6)  # Rank
        self.writeVInt(3750) # Starpoints
        self.writeVInt(7)  # Rank
        self.writeVInt(4500) # Starpoints
        self.writeVInt(8)  # Rank
        self.writeVInt(5500) # Starpoints
        self.writeVInt(9)  # Rank
        self.writeVInt(7000) # Starpoints
        self.writeVInt(10)  # Rank
        self.writeVInt(8750) # Starpoints
        self.writeVInt(11)  # Rank
        self.writeVInt(10000) # Starpoints
        self.writeVInt(12)  # Rank
        self.writeVInt(12500) # Starpoints
        self.writeVInt(13)  # Rank
        self.writeVInt(15000) # Starpoints
        self.writeVInt(14)  # Rank
        self.writeVInt(17500) # Starpoints
        self.writeVInt(15)  # Rank
        self.writeVInt(20000) # Starpoints
        self.writeVInt(16)  # Rank
        self.writeVInt(25000) # Starpoints
        self.writeVInt(17)  # Rank
        self.writeVInt(30000) # Starpoints
        self.writeVInt(18)  # Rank
        self.writeVInt(40000) # Starpoints
        self.writeVInt(19)  # Rank
        self.writeVInt(50000) # Starpoints
        # Power League Data Array End #
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeBoolean(False)  # ChronosTextEntry
        self.writeBoolean(False)
        self.writeBoolean(False) # ChronosTextEntry
        self.writeBoolean(False)
        self.writeVInt(0)
        self.writeBoolean(False) # ChronosFileEntry
        self.writeBoolean(False)
        self.writeVInt(-1)
        
        # Power League Team Mode #
        self.writeVInt(0)
        self.writeVInt(15)  # EventType
        self.writeVInt(0)  # EventsBeginCountdown
        self.writeVInt(5184000)  # Timer
        self.writeVInt(0)  # Tokens
        self.writeDataReference(0, 4)  # MapID
        self.writeVInt(-64)  # GameModeVariation
        self.writeVInt(2)  # State
        self.writeString()
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeVInt(3)
        self.writeVInt(0)  # Modifiers
        self.writeVInt(60)
        self.writeVInt(0)
        self.writeBoolean(False)  # Map Maker Map Structure Array
        self.writeVInt(0)
        self.writeBoolean(True)  # Power League Data Array
        # Power League Data Array Start #
        self.writeVInt(9) # Season
        self.writeString("TID_BRAWL_PASS_SEASON_13") # Name Season
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeVInt(3) # Quests Count
        
        self.writeByte(3) # LogicRewardConfig
        self.writeByte(4) # Quest Type
        self.writeVInt(30) # Rank
        self.writeVInt(1) # Item Array
        self.writeVInt(25) # ItemType
        self.writeVInt(1) 
        self.writeVInt(0)
        self.writeVInt(127) # Thumbnail ID
        
        self.writeByte(3) # LogicRewardConfig
        self.writeByte(2) # Quest Type
        self.writeVInt(7) # Rank
        self.writeVInt(1) # Item Array
        self.writeVInt(25) # ItemType
        self.writeVInt(1) 
        self.writeVInt(0)
        self.writeVInt(128) # Thumbnail ID
        
        self.writeByte(3) # LogicRewardConfig
        self.writeByte(4) # Quest Type
        self.writeVInt(60) # Wins need
        self.writeVInt(1) # Item Array
        self.writeVInt(26) # ItemType
        self.writeVInt(1) 
        self.writeVInt(0)
        self.writeVInt(568) # SkinID
        
        self.writeVInt(19) # Road Count
        
        self.writeVInt(1) # Rank
        self.writeVInt(500) # Starpoints
        self.writeVInt(2) # Rank
        self.writeVInt(1000) # Starpoints
        self.writeVInt(3)  # Rank
        self.writeVInt(2000) # Starpoints
        self.writeVInt(4)  # Rank
        self.writeVInt(2500) # Starpoints
        self.writeVInt(5)  # Rank
        self.writeVInt(3000) # Starpoints
        self.writeVInt(6)  # Rank
        self.writeVInt(3750) # Starpoints
        self.writeVInt(7)  # Rank
        self.writeVInt(4500) # Starpoints
        self.writeVInt(8)  # Rank
        self.writeVInt(5500) # Starpoints
        self.writeVInt(9)  # Rank
        self.writeVInt(7000) # Starpoints
        self.writeVInt(10)  # Rank
        self.writeVInt(8750) # Starpoints
        self.writeVInt(11)  # Rank
        self.writeVInt(10000) # Starpoints
        self.writeVInt(12)  # Rank
        self.writeVInt(12500) # Starpoints
        self.writeVInt(13)  # Rank
        self.writeVInt(15000) # Starpoints
        self.writeVInt(14)  # Rank
        self.writeVInt(17500) # Starpoints
        self.writeVInt(15)  # Rank
        self.writeVInt(20000) # Starpoints
        self.writeVInt(16)  # Rank
        self.writeVInt(25000) # Starpoints
        self.writeVInt(17)  # Rank
        self.writeVInt(30000) # Starpoints
        self.writeVInt(18)  # Rank
        self.writeVInt(40000) # Starpoints
        self.writeVInt(19)  # Rank
        self.writeVInt(50000) # Starpoints
        # Power League Data Array End #
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeBoolean(False)  # ChronosTextEntry
        self.writeBoolean(False)
        self.writeBoolean(False) # ChronosTextEntry
        self.writeBoolean(False)
        self.writeVInt(0)
        self.writeBoolean(False) # ChronosFileEntry
        self.writeBoolean(False)
        self.writeVInt(-1)

        self.writeVInt(0) # Comming Events

        self.writeVInt(10)  # Brawler Upgrade Cost
        self.writeVInt(20) # 2 Level
        self.writeVInt(35) # 3 Level
        self.writeVInt(75) # 4 Level
        self.writeVInt(140) # 5 Level
        self.writeVInt(290) # 6 Level
        self.writeVInt(480) # 7 Level
        self.writeVInt(800) # 8 Level
        self.writeVInt(1250) # 9 Level
        self.writeVInt(1875) # 10 Level
        self.writeVInt(2800) # 11 Level

        self.writeVInt(4)  # Shop Coins Price
        self.writeVInt(20)
        self.writeVInt(50)
        self.writeVInt(140)
        self.writeVInt(280)

        self.writeVInt(4)  # Shop Coins Count
        self.writeVInt(150) # Count
        self.writeVInt(400) # Count
        self.writeVInt(1200) # Count
        self.writeVInt(2600) # Count
        
        self.writeBoolean(True)  # Show Offers Packs        
        
        self.writeVInt(0) # Locked For Chronos
        for x in range(0):
            self.writeDataReference(16, 0)
            self.writeInt(0) # Timer
            self.writeInt(0)

        self.writeVInt(1)
        for x in range(1):
            self.writeInt(1)
            self.writeInt(41000047) # Theme ID
                                     
        self.writeVInt(0) # Timed Int Entry Count
        self.writeVInt(0) # Custom Event

        self.writeVInt(0)
        self.writeVInt(0)
        self.writeVInt(0)

        self.writeInt(0) # Low ID
        self.writeInt(1) # High ID

        self.writeVInt(0) # Notification Factory
        
        self.writeVInt(-1)
        self.writeBoolean(False)
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeVInt(0)
        
        self.writeBoolean(False)

        self.writeVInt(0)
        self.writeVInt(1)
        self.writeVInt(0)
        self.writeVInt(1)
        self.writeVInt(0)
        self.writeVInt(1)
        
        self.writeStringReference("F1ize") # Player Name
        self.writeBoolean(True) # Name Set
        
        self.writeInt(0)

        self.writeVInt(17) # Commodity Count
        
        unlocked_brawler = [0, 4, 8, 12, 16, 20, 24, 28, 32, 36, 40, 44, 48, 52, 56, 60, 64, 68, 72, 95, 100, 105, 110, 115, 120, 125, 130, 177, 182, 188, 194, 200, 206, 218, 224, 230, 236, 279, 296, 303, 320, 327, 334, 341, 358, 365, 372, 379, 386, 393, 410, 417, 427, 434, 448, 466, 474, 491, 499, 507]
        self.writeVInt(len(unlocked_brawler) + 6)
        for x in unlocked_brawler:
            self.writeDataReference(23, x)
            self.writeVInt(-1)
            self.writeVInt(1)
            
        self.writeDataReference(5, 1)
        self.writeVInt(-1)
        self.writeVInt(1000) # Brawl Box Tokens 
        
        self.writeDataReference(5, 9)
        self.writeVInt(-1)
        self.writeVInt(100) # Big Box Tokens                                                    
        self.writeDataReference(5, 8)
        self.writeVInt(-1)
        self.writeVInt(9999) # Coins
    
        self.writeDataReference(5, 10)
        self.writeVInt(-1)
        self.writeVInt(4444) # Star Points
                                             
        self.writeDataReference(5, 13)
        self.writeVInt(-1)        
        self.writeVInt(8888) # Club Coins       
        
        self.writeDataReference(5, 18)
        self.writeVInt(-1)
        self.writeVInt(5) # Unlocked Sprays Slots                         
        self.writeVInt(68) # Trophies
        for x in range(68):
            self.writeDataReference(16, x)
            self.writeVInt(-1)
            self.writeVInt(0)
        
        self.writeVInt(68) # Highest Trophies
        for x in range(68):
            self.writeDataReference(16, x)
            self.writeVInt(-1)
            self.writeVInt(0)

        self.writeVInt(0) # Array

        self.writeVInt(68) # Power Points
        for x in range(68):
            self.writeDataReference(16, x)
            self.writeVInt(-1)
            self.writeVInt(1)
        
        self.writeVInt(68) # Power Level
        for x in range(68):
            self.writeDataReference(16, x)
            self.writeVInt(-1)
            self.writeVInt(10)

        self.writeVInt(0) # Star Powers        
        for x in range(0):
            self.writeDataReference(16, x)
            self.writeVInt(-1)
            self.writeVInt(0)
            
        self.writeVInt(68) # State
        for x in range(68):
            self.writeDataReference(16, x)
            self.writeVInt(-1)
            self.writeVInt(2)

        self.writeVInt(0) # Array
        self.writeVInt(0) # Array
        self.writeVInt(0) # Array
        self.writeVInt(0) # Array
        self.writeVInt(0) # Array
        self.writeVInt(0) # Array
        self.writeVInt(0) # Array
        self.writeVInt(0) # Array

        self.writeVInt(6666) # Diamonds
        self.writeVInt(6666) # Free Diamonds
        self.writeVInt(999) # Player Level
        self.writeVInt(100)
        self.writeVInt(0) # CumulativePurchasedDiamonds or Avatar User Level Tier | 10000 < Level Tier = 3 | 1000 < Level Tier = 2 | 0 < Level Tier = 1
        self.writeVInt(0) # Battle Count
        self.writeVInt(0) # WinCount
        self.writeVInt(0) # LoseCount
        self.writeVInt(0) # WinLooseStreak
        self.writeVInt(0) # NpcWinCount
        self.writeVInt(0) # NpcLoseCount
        self.writeVInt(2) # TutorialState | shouldGoToFirstTutorialBattle = State == 0
        self.writeVInt(5)
        self.writeVInt(0)
        self.writeVInt(0)

        
    def decode(self):
        fields = {}
        return fields

    def execute(message, calling_instance, fields):
        pass

    def getMessageType(self):
        return 24101

    def getMessageVersion(self):
        return self.messageVersion