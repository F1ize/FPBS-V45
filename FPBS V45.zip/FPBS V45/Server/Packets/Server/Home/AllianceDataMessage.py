from Server.Packets.PiranhaMessage import PiranhaMessage


class AllianceDataMessage(PiranhaMessage):
    def __init__(self, messageData):
        super().__init__(messageData)
        self.messageVersion = 0

    def encode(self, fields, player):
        self.writeBoolean(True)

        self.writeLong(0, 1) # Alliance ID
        self.writeString("V45") # Alliance Name
        self.writeDataReference(8, 19) # Alliance Icon
        self.writeVInt(1) # Type
        self.writeVInt(1) # Member Count
        self.writeVInt(0) # Total Trophies
        self.writeVInt(0) # Minimum Trophies To Enter
        self.writeVInt(0) 
        self.writeString("UA") # Location
        self.writeVInt(1) # People Online
        self.writeBoolean(True) # Family Friendly
        self.writeVInt(0)

        self.writeString("Nigge")

        self.writeVInt(1) # Member Count
        self.writeLong(0, 1) # Player ID
        self.writeVInt(2) # Role
        self.writeVInt(0) # Trophies
        self.writeVInt(2) # Status: 0=Offline 2=Online
        self.writeVInt(1) # Last Connected Time Seconds 
        # whatIsThat = 5
        self.writeVInt(1)
        self.writeVInt(1) # Idk
        self.writeVInt(19) # Power League Rank
        self.writeBoolean(False) # DoNotDisturb TODO: Do not disturb sync

        self.writeString("F1ize") # Player Name
        self.writeVInt(100)
        self.writeVInt(28000000) # Player Thumbnail
        self.writeVInt(43000000) # Player Name Color
        self.writeVInt(46000001) # Color Gradients

        self.writeVInt(-1)
        self.writeBoolean(False)

        self.writeVInt(0) # Club Leauge?

    def decode(self):
        fields = {}
        super().decode(fields)
        return {}

    def execute(message, calling_instance, fields):
        pass

    def getMessageType(self):
        return 24301

    def getMessageVersion(self):
        return self.messageVersion