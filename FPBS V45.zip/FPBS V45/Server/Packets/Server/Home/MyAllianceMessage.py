from Server.Packets.PiranhaMessage import PiranhaMessage


class MyAllianceMessage(PiranhaMessage):
    def __init__(self, messageData):
        super().__init__(messageData)
        self.messageVersion = 0

    def encode(self, fields, player):
        self.writeVInt(1) # Online People
        self.writeBoolean(True)
        self.writeDataReference(25, 2) # Role

        self.writeLong(0, 1)
        self.writeString("V45")
        self.writeDataReference(8, 19) # Badge
        self.writeVInt(3) # Type
        self.writeVInt(1) # Total Members
        self.writeVInt(0) # Total Trophies
        self.writeVInt(0) # Trophies Required
        self.writeDataReference(0)
        self.writeString("UA") # Region
        self.writeVInt(0)
        self.writeBoolean(True) # Family Friendly
        self.writeVInt(0)

        self.writeBoolean(False)

    def decode(self):
        fields = {}
        super().decode(fields)
        return {}

    def execute(message, calling_instance, fields):
        pass

    def getMessageType(self):
        return 24399

    def getMessageVersion(self):
        return self.messageVersion