from Server.Packets.PiranhaMessage import PiranhaMessage


class PlayerProfileMessage(PiranhaMessage):
    def __init__(self, messageData):
        super().__init__(messageData)
        self.messageVersion = 0

    def encode(self, fields, player):

        self.writeVInt(0)  # High Id
        self.writeVInt(1)  # Low Id
        self.writeDataReference(0)
        self.writeVInt(63)
        for i in range(63):
            self.writeDataReference(16, i)
            self.writeDataReference(0)
            self.writeVInt(0) # Trophies
            self.writeVInt(0) # Highest Trophies
            self.writeVInt(11) # Power Level
        
        self.writeVInt(16) 

        self.writeVInt(1) 
        self.writeVInt(0) # 3v3 Victories

        self.writeVInt(2)
        self.writeVInt(0) # Experince

        self.writeVInt(3)
        self.writeVInt(0) # Current Trophies

        self.writeVInt(4)
        self.writeVInt(0) # Highest Trophies

        self.writeVInt(5) 
        self.writeVInt(5) # Unlocked Brawlers

        self.writeVInt(8)
        self.writeVInt(0) # Solo Victories

        self.writeVInt(11) 
        self.writeVInt(0) # Duo Victories

        self.writeVInt(9) 
        self.writeVInt(20) # Highest Level Robo Rumble

        self.writeVInt(12) 
        self.writeVInt(20) # Highest Level Boss Fight

        self.writeVInt(13)
        self.writeVInt(19) # Highest Power League Points

        self.writeVInt(14)
        self.writeVInt(19) # Some Power League Stuff

        self.writeVInt(15)
        self.writeVInt(15) # Most Challenge Wins

        self.writeVInt(16)
        self.writeVInt(20) # Highest Level City Rampage

        self.writeVInt(18)
        self.writeVInt(19) # Highest Solo Power League Rank

        self.writeVInt(17)
        self.writeVInt(19) # Highest Team Power League Rank

        self.writeVInt(19)
        self.writeVInt(19) # Highest Club League Rank
        

        self.writeString("F1ize")  # Player Info
        self.writeVInt(100)
        self.writeVInt(28000000)
        self.writeVInt(43000000)
        self.writeVInt(0)

        self.writeBoolean(True)
        self.writeVInt(0)

        self.writeString("Hello World")
        self.writeVInt(0)
        self.writeVInt(0)

        self.writeBoolean(True) # Alliance
        self.writeInt(0) # Alliance Low ID
        self.writeInt(1) # Alliance High ID
        self.writeString("Haccers") # Alliance Name
        self.writeDataReference(8, 1) # Alliance Icon
        self.writeVInt(1) # Type
        self.writeVInt(1) # Member Count
        self.writeVInt(99999) # Total Trophies
        self.writeVInt(0) # Minimum Trophies To Enter
        self.writeDataReference(0)
        self.writeString("UA") # Location
        self.writeVInt(4) # Unknown
        self.writeBoolean(True) # Family Friendly
        self.writeVInt(0)        
        self.writeDataReference(25, 1) # Alliance Role		                    
        

        
    def decode(self):
        return {}

    def execute(message, calling_instance, fields):
        pass

    def getMessageType(self):
        return 24113

    def getMessageVersion(self):
        return self.messageVersion