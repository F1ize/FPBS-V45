from Server.Packets.PiranhaMessage import PiranhaMessage

class BattleEndMessage(PiranhaMessage):
    def __init__(self, messageData):
        super().__init__(messageData)
        self.messageVersion = 0

    def encode(self, fields, player):
        self.writeVInt(1) # Battle End Game Mode
        self.writeVInt(1) # Result (Victory/Defeat/Draw/Rank Score)
        self.writeVInt(0) # Tokens Gained
        self.writeVInt(0) # Trophies Result
        self.writeVInt(0) # Power Play Points Gained (Pro League Points)
        self.writeVInt(0) # Doubled Tokens (Double Keys)
        self.writeVInt(0) # Double Token Event (Double Event Keys)
        self.writeVInt(0) # Token Doubler Remaining (Double Keys Remaining)
        self.writeVInt(0) # Game Lenght In Seconds
        self.writeVInt(0) # Epic Win Power Play Points Gained
        self.writeVInt(0) # Championship Level Passed
        self.writeBoolean(False) # Challenge Reward Array
        self.writeVInt(0) # Challenge Reward Amount
        self.writeVInt(0) # Championship Losses Left
        self.writeBoolean(False)  # Championship Array
        self.writeVInt(0) # Coin Shower Event
        self.writeVInt(0) # Underdog Trophies
        self.writeVInt(0) # SD+ Win Trophies
        self.writeVInt(0) # SD+ Lose Trophies
        self.writeVInt(0) # Battle Result Type
        self.writeBoolean(False)
        self.writeBoolean(False) # Experience is Over
        self.writeBoolean(False) # Battle Tokens is Over
        self.writeBoolean(False) # Battle End State Off
        self.writeBoolean(True) # Trophies is  nit Off
        self.writeBoolean(False) # Battle End State is Over
        self.writeBoolean(False) # Power Play Battle End
        self.writeVInt(-1) # Challenge Type
        self.writeBoolean(False) # ChampionShip Cleared and Beta Quests

        self.writeVInt(1)  # Players
        self.writeBoolean(False)
        self.writeBoolean(False)
        self.writeDataReference(16, 66)  # BrawlerID
        self.writeDataReference(29, 0)  # SkinID
        self.writeVInt(1)
        for i in range(1):
         self.writeVInt(1250)
        self.writeVInt(1)
        for i in range(1):
         self.writeVInt(11)
        self.writeVInt(1)
        for i in range(1):
         self.writeVInt(0)
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeBoolean(True)
        self.writeVInt(0)  # High Id
        self.writeVInt(1)  # Low Id
        self.writeString("F1ize")  # Player Name
        self.writeVInt(200)
        self.writeVInt(28000000)  # Player Thumbnail
        self.writeVInt(43000000)  # Name Color
        self.writeVInt(46000000) # Brawl Pass Gradient
        if heroEntry["IsPlayer"]:
            self.writeBoolean(True)
            self.writeVLong(5, 4181497)
            self.writeString('Orange eSPORT')
            self.writeDataReference(8, 16) 
            
        self.writeVInt(0)

        self.writeVInt(0)

        self.writeVInt(0)

        self.writeVInt(2)

        self.writeVInt(1)
        self.writeVInt(0)
        self.writeVInt(0)

        self.writeVInt(5)
        self.writeVInt(0)
        self.writeVInt(0)

        self.writeDataReference(28, 0)
        self.writeBoolean(False)
        self.writeBoolean(False)
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeBoolean(False)
        self.writeVInt(-1)
        self.writeBoolean(False)

        print(self.messagePayload.hex())

    def decode(self):
        fields = {}
        return {}

    def execute(message, calling_instance, fields):
        pass

    def getMessageType(self):
        return 23456

    def getMessageVersion(self):
        return self.messageVersion