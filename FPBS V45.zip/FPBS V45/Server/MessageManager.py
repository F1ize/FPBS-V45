import traceback

import Settings
from Server.Logic.LogicLaserMessageFactory import LogicLaserMessageFactory
from Server.Messaging import Messaging


class MessageManager:
    def receiveMessage(self, messageType, messagePayload):
        message = LogicLaserMessageFactory.createMessageByType(messageType, messagePayload)
        if message is not None:
            try:
                if Settings.settings["Proxy"] == False and message.isServerToClient():
                    message.encode()
                else:
                    message.fields = message.decode()
                    if Settings.settings["Proxy"] == False:
                        message.execute(self, message.fields)

            except Exception:
                print(traceback.format_exc())
        
        if Settings.settings["Proxy"] == False:
            Messaging.sendMessage(23457, {"Socket": self.client}, self.player)